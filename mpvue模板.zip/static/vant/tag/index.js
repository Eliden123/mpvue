import { create } from '../common/create';

create({
  props: {
    type: String,
    mark: Boolean,
    plain: Boolean
  }
});

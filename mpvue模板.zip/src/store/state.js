//store为实例化生成的
const state = {
    openId:'初始openId'
}

export default state;
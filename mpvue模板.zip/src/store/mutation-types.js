// 方便书写和检测
export const SET_OPEN_ID = 'SET_OPEN_ID';
// 配置
const host = 'https://www.xxx.com' // 生产
const appid = '';
const appKey = '';

const config = {
    host,
    appid,
    appKey,
}
export default config;
import Vue from 'vue'
import Hello from './hello'

const app = new Vue(Hello)
app.$mount()

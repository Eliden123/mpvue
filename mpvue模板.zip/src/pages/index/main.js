import Vue from 'vue'
import Index from './index'

const app = new Vue(Index)
app.$mount()

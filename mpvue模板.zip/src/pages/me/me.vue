<template>
  <div>个人中心</div>
</template>

<script>
    export default {
        data() {
            return {}
        },

        components: {},

        methods: {

        },

        created() {}
    }
</script>

<style scoped>
</style>